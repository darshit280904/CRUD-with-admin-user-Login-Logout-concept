const mongoose = require('mongoose');

const marksSchema = new mongoose.Schema({
    userId:
    {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    physics:
    {
        type: Number,
        required: true,
        min: 0, max: 100
    },
    chemistry:
    {
        type: Number,
        required: true,
        min: 0, max: 100
    },
    biology:
    {
        type: Number,
        required: true,
        min: 0, max: 100
    }
});
module.exports = mongoose.model('Marks', marksSchema);
