const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema({
    rating: 
    { 
        type: String, 
        required: true,
        min: 1,
        max: 5
    },
    description: 
    { 
        type: String, 
        required: true 
    },
    image: 
    { 
        type: String 
    } // file path store karse
});

module.exports = mongoose.model('Review', reviewSchema);
