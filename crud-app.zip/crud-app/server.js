const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const session = require('express-session');
const path = require('path');
const multer = require('multer');

const User = require('./models/User');
const Marks = require('./models/marks');
const Review = require('./models/Review');

const app = express();


mongoose.connect('mongodb://127.0.0.1:27017/crud_demo')
    .then(() => console.log('MongoDB Connected'))
    .catch(err => console.log(err));

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(methodOverride('_method'));
app.use(express.static("public"));
app.use('/uploads', express.static("uploads")); // uploads folder serve karva

app.use(session({
    secret: "mySecretKey",
    resave: false,
    saveUninitialized: false
}));

                                                // Multer 
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');  // uploads folder ma save thase
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname)); // unique file name
    }
});
const upload = multer({ storage: storage });


                                                        // Index
app.get('/index', async (req, res) => {
    if (!req.session.user) {
        return res.redirect('/');
    }
    const users = await User.find();
    res.render('index', { users, currentUser: req.session.user });
    console.log('Index Page Rendered \n \n');
});

                                                        // Login Page
app.get('/', (req, res) => {
    res.render('login');
    console.log('Home Page Rendered \n \n');
});

app.get('/login', (req, res) => {
    res.render('login');
    console.log('Login Page Rendered \n \n');
});

app.post('/login', async (req, res) => {
    const { name, email } = req.body;
    console.log('\n \nLogin From this Account :- \n', name, email, '\n \n');
    try {
        const user = await User.findOne({ name, email });
        if (!user) {
            return res.send("Invalid Name or Email");
        }
        req.session.user = user;
        res.redirect('/index');
    } catch (err) {
        console.log(err);
        res.send("Error occurred");
    }
});

                                                        // Sign-up
app.get('/signup', (req, res) => {
    res.render('signup');
    console.log('Signup Page Rendered \n \n');
});

app.post('/signup', async (req, res) => {
    const { name, email, age, physics, chemistry, biology } = req.body;
    const user = new User({ name, email, age });
    await user.save();

    const marks = new Marks({ userId: user._id, physics, chemistry, biology });
    await marks.save();

    res.redirect('/index');
    console.log('User and Marks Created From Signup-page:', user, marks, '\n \n');
});

                                                    // User CRUD
app.get('/new', (req, res) => {
    res.render('new');
});

app.post('/', async (req, res) => {
    const { name, email, age, physics, chemistry, biology } = req.body;
    const user = new User({ name, email, age });
    await user.save();
    const marks = new Marks({ userId: user._id, physics, chemistry, biology });
    await marks.save();
    res.redirect('/index');
    console.log('User and Marks Created:', user, marks, '\n \n');
});

app.get('/edit/:id', async (req, res) => {
    const user = await User.findById(req.params.id);
    const marks = await Marks.findOne({ userId: req.params.id });
    res.render('edit', { user, marks });
    console.log('\n \n Editing User Route Open:', user, '\n \n Marks:', marks, '\n \n');
});

app.put('/:id', async (req, res) => {
    const { name, email, age, physics, chemistry, biology } = req.body;
    await User.findByIdAndUpdate(req.params.id, { name, email, age });
    await Marks.findOneAndUpdate(
        { userId: req.params.id },
        { physics, chemistry, biology },
        { upsert: true }
    );
    res.redirect('/index');
    console.log('\n \n User and Marks Updated: \n', { name, email, age }, { physics, chemistry, biology }, '\n \n');
});

app.get('/view/:id', async (req, res) => {
    const user = await User.findById(req.params.id);
    const marks = await Marks.findOne({ userId: req.params.id });
    res.render('view', { user, marks });
    console.log('Viewing User:', user, 'Marks:', marks, '\n \n');
});

app.get('/delete/:id', async (req, res) => {
    const user = await User.findById(req.params.id);
    const marks = await Marks.findOne({ userId: req.params.id });
    await User.findByIdAndDelete(req.params.id);
    await Marks.deleteOne({ userId: req.params.id });
    res.redirect('/');
    console.log('Deleted User and Marks with ID:\n \n', user, marks, req.params.id, '\n \n');
});


                                                            // Review

// Show review form + list all reviews
app.get('/review', async (req, res) => {
    const reviews = await Review.find();
    res.render('review', { reviews });
    console.log('Review Page Rendered \n \n');
});

                                                // Handle review submit
app.post('/review', upload.single('image'), async (req, res) => {
    try {
        const { rating, description } = req.body;
        const newReview = new Review({
            rating,
            description,
            image: req.file ? req.file.path : null
        });
        await newReview.save();
        console.log('Review Saved:', newReview);
        res.redirect('/index');
    } catch (err) {
        console.log(err);
        res.send("Error Saving Review");
    }
});




app.listen(3000, () => console.log('Server Running On Port 3000'));
